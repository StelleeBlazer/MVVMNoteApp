package com.example.notes.data

enum class Priority {
    HIGH,
    MEDIUM,
    LOW
}